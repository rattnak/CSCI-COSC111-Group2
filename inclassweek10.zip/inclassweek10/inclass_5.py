from operator import truediv


def leap_year(year):
    if year % 4 == 0:
        return True
    else:
        return False
    
year = int(input("Enter a year: "))

a = leap_year(year)

print(a)
    