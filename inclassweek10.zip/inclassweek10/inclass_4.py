def combine(spam):
    b = []
    for in in spam:


    return b


spam = ['boduk' , 'tea eye winner' , 'joe']

a = combine(spam)

print(a)