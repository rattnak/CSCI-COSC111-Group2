sq_numbers = []
number = [1,2,3,4,5,6,7]

for i in number:
    a = i**2
    sq_numbers.append(a)

print(sq_numbers)
    

