from multiprocessing.sharedctypes import Value
from operator import index


def remove_dupli(list1):
    list2 = []
    for index, Value in enumerate(list1):
        prev_index = index - 1
        current = array[index]
        if Value != Value:
            list2 += Value
    return list2
        
            


list1 = [1,15,50, 20, 20 ,20]

print(remove_dupli(list1))