

def large_num(numbers):
    num = max(numbers)
    return num
    
numbers = [1,2,8,4,36,2,3,10]

a = large_num(numbers)

print(a)